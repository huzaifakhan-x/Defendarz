const firebaseConfig = {
 apiKey: "AIzaSyB57s8Uy6xmlvJ-CkhvWEqItgTG-66Skxo",
  authDomain: "dha111.firebaseapp.com",
  projectId: "dha111",
  storageBucket: "dha111.firebasestorage.app",
  messagingSenderId: "715589079689",
  appId: "1:715589079689:web:73db8fa49495cf98e6ec58"
};
  module.exports = { firebaseConfig }