/* =====================================================
   MOBILE FORM WIZARD - JavaScript
   Step navigation, validation, and file upload handling
   ===================================================== */

class MobileFormWizard {
    constructor(options = {}) {
        this.container = document.querySelector('.mf-container');
        this.steps = document.querySelectorAll('.mf-step');
        this.progressDots = document.querySelectorAll('.mf-progress-dot');
        this.progressLines = document.querySelectorAll('.mf-progress-line');
        this.prevBtn = document.querySelector('.mf-btn-secondary');
        this.nextBtn = document.querySelector('.mf-btn-primary');

        this.currentStep = 0;
        this.totalSteps = this.steps.length;
        this.uploadedFiles = {};

        this.options = {
            onSubmit: options.onSubmit || null,
            validateStep: options.validateStep || this.defaultValidateStep.bind(this),
            ...options
        };

        this.init();
    }

    init() {
        this.updateProgress();
        this.updateButtons();
        this.attachEventListeners();
        this.initFileUploads();
    }

    attachEventListeners() {
        if (this.nextBtn) {
            this.nextBtn.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.currentStep === this.totalSteps - 1) {
                    this.submit();
                } else {
                    this.nextStep();
                }
            });
        }

        if (this.prevBtn) {
            this.prevBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.prevStep();
            });
        }

        // Progress dot click navigation
        this.progressDots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                if (index < this.currentStep) {
                    this.goToStep(index);
                }
            });
        });
    }

    nextStep() {
        if (this.options.validateStep(this.currentStep)) {
            if (this.currentStep < this.totalSteps - 1) {
                this.steps[this.currentStep].classList.remove('active');
                this.currentStep++;
                this.steps[this.currentStep].classList.add('active');
                this.updateProgress();
                this.updateButtons();
                this.scrollToTop();
            }
        }
    }

    prevStep() {
        if (this.currentStep > 0) {
            this.steps[this.currentStep].classList.remove('active');
            this.currentStep--;
            this.steps[this.currentStep].classList.add('active');
            this.updateProgress();
            this.updateButtons();
            this.scrollToTop();
        }
    }

    goToStep(index) {
        if (index >= 0 && index < this.totalSteps) {
            this.steps[this.currentStep].classList.remove('active');
            this.currentStep = index;
            this.steps[this.currentStep].classList.add('active');
            this.updateProgress();
            this.updateButtons();
            this.scrollToTop();
        }
    }

    updateProgress() {
        this.progressDots.forEach((dot, index) => {
            dot.classList.remove('active', 'completed');
            if (index < this.currentStep) {
                dot.classList.add('completed');
                dot.innerHTML = '<i class="fas fa-check"></i>';
            } else if (index === this.currentStep) {
                dot.classList.add('active');
                dot.innerHTML = index + 1;
            } else {
                dot.innerHTML = index + 1;
            }
        });

        this.progressLines.forEach((line, index) => {
            line.classList.toggle('completed', index < this.currentStep);
        });
    }

    updateButtons() {
        if (this.prevBtn) {
            this.prevBtn.style.display = this.currentStep === 0 ? 'none' : 'flex';
        }

        if (this.nextBtn) {
            const isLastStep = this.currentStep === this.totalSteps - 1;
            this.nextBtn.innerHTML = isLastStep
                ? '<i class="fas fa-paper-plane"></i> Submit'
                : 'Next <i class="fas fa-arrow-right"></i>';
        }
    }

    scrollToTop() {
        const stepsContainer = document.querySelector('.mf-steps-container');
        if (stepsContainer) {
            stepsContainer.scrollTop = 0;
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    defaultValidateStep(stepIndex) {
        const step = this.steps[stepIndex];
        const inputs = step.querySelectorAll('input[required], textarea[required], select[required]');
        let isValid = true;

        inputs.forEach(input => {
            if (input.type === 'file') {
                // Check if file was uploaded
                if (!this.uploadedFiles[input.id]) {
                    isValid = false;
                    this.showError(input);
                } else {
                    this.clearError(input);
                }
            } else if (!input.value.trim()) {
                isValid = false;
                this.showError(input);
            } else {
                this.clearError(input);
            }
        });

        if (!isValid) {
            this.showValidationMessage('Please fill in all required fields.');
        }

        return isValid;
    }

    showError(input) {
        input.classList.add('error');
        const uploadBox = input.closest('.mf-upload-box');
        if (uploadBox) {
            uploadBox.style.borderColor = 'var(--mf-error)';
        }
    }

    clearError(input) {
        input.classList.remove('error');
        const uploadBox = input.closest('.mf-upload-box');
        if (uploadBox) {
            uploadBox.style.borderColor = '';
        }
    }

    showValidationMessage(message) {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'warning',
                title: 'Required Fields',
                text: message,
                confirmButtonColor: '#1E58C8'
            });
        } else {
            alert(message);
        }
    }

    // File Upload Handling
    initFileUploads() {
        const uploadInputs = this.container.querySelectorAll('.mf-upload input[type="file"]');

        uploadInputs.forEach(input => {
            input.addEventListener('change', (e) => this.handleFileSelect(e));
        });
    }

    handleFileSelect(event) {
        const input = event.target;
        const file = input.files[0];
        const uploadBox = input.closest('.mf-upload');
        const progressBar = uploadBox.querySelector('.mf-upload-progress-bar');
        const previewContainer = uploadBox.querySelector('.mf-upload-preview');
        const uploadIcon = uploadBox.querySelector('.mf-upload-icon i');
        const uploadTitle = uploadBox.querySelector('.mf-upload-title');

        if (!file) return;

        // Update UI to show uploading
        if (uploadIcon) {
            uploadIcon.className = 'fas fa-spinner mf-spinner';
        }
        if (uploadTitle) {
            uploadTitle.textContent = 'Uploading...';
        }

        // Simulate progress
        let progress = 0;
        const progressInterval = setInterval(() => {
            progress += Math.random() * 15;
            if (progress >= 90) {
                progress = 90;
                clearInterval(progressInterval);
            }
            if (progressBar) {
                progressBar.style.width = progress + '%';
            }
        }, 100);

        // Upload to Firebase (if available)
        if (typeof firebase !== 'undefined' && firebase.storage) {
            this.uploadToFirebase(file, input.id)
                .then(url => {
                    clearInterval(progressInterval);
                    this.uploadedFiles[input.id] = url;
                    this.showUploadSuccess(uploadBox, file, uploadIcon, uploadTitle, progressBar);
                    this.createPreview(file, previewContainer, input);
                })
                .catch(error => {
                    clearInterval(progressInterval);
                    console.error('Upload error:', error);
                    this.showUploadError(uploadBox, uploadIcon, uploadTitle, progressBar);
                });
        } else {
            // No Firebase - just show local preview
            setTimeout(() => {
                clearInterval(progressInterval);
                this.uploadedFiles[input.id] = 'local-' + file.name;
                this.showUploadSuccess(uploadBox, file, uploadIcon, uploadTitle, progressBar);
                this.createPreview(file, previewContainer, input);
            }, 500);
        }
    }

    async uploadToFirebase(file, inputId) {
        const cookieValue = this.getCookie('namecookie') || 'anonymous';
        const filePath = `${cookieValue}/${Date.now()}_${file.name}`;
        const storageRef = firebase.storage().ref(filePath);

        await storageRef.put(file);
        return await storageRef.getDownloadURL();
    }

    getCookie(name) {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                return decodeURIComponent(cookie.substring(name.length + 1));
            }
        }
        return null;
    }

    showUploadSuccess(uploadBox, file, icon, title, progressBar) {
        uploadBox.classList.add('active');
        if (icon) {
            icon.className = 'fas fa-check-circle mf-success-check';
            icon.parentElement.classList.add('success');
        }
        if (title) {
            title.textContent = file.name;
        }
        if (progressBar) {
            progressBar.style.width = '100%';
            progressBar.classList.add('success');
        }
    }

    showUploadError(uploadBox, icon, title, progressBar) {
        if (icon) {
            icon.className = 'fas fa-exclamation-triangle';
        }
        if (title) {
            title.textContent = 'Upload failed - try again';
        }
        if (progressBar) {
            progressBar.style.width = '0%';
        }
    }

    createPreview(file, container, input) {
        if (!container) return;

        container.innerHTML = '';

        const preview = document.createElement('div');
        preview.className = 'mf-upload-preview';

        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                preview.innerHTML = `
                    <img src="${e.target.result}" alt="${file.name}">
                    <span class="mf-upload-preview-name">${file.name}</span>
                    <button type="button" class="mf-upload-preview-remove" data-input="${input.id}">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                container.appendChild(preview);
                this.attachRemoveHandler(preview, input);
            };
            reader.readAsDataURL(file);
        } else {
            preview.innerHTML = `
                <i class="fas fa-file-pdf" style="font-size: 24px; color: var(--mf-primary);"></i>
                <span class="mf-upload-preview-name">${file.name}</span>
                <button type="button" class="mf-upload-preview-remove" data-input="${input.id}">
                    <i class="fas fa-times"></i>
                </button>
            `;
            container.appendChild(preview);
            this.attachRemoveHandler(preview, input);
        }
    }

    attachRemoveHandler(preview, input) {
        const removeBtn = preview.querySelector('.mf-upload-preview-remove');
        if (removeBtn) {
            removeBtn.addEventListener('click', () => {
                this.removeFile(input);
                preview.remove();
            });
        }
    }

    removeFile(input) {
        const uploadBox = input.closest('.mf-upload');
        const icon = uploadBox.querySelector('.mf-upload-icon i');
        const title = uploadBox.querySelector('.mf-upload-title');
        const progressBar = uploadBox.querySelector('.mf-upload-progress-bar');

        input.value = '';
        delete this.uploadedFiles[input.id];

        uploadBox.classList.remove('active');
        if (icon) {
            icon.className = 'fas fa-cloud-upload-alt';
            icon.parentElement.classList.remove('success');
        }
        if (title) {
            title.textContent = 'Tap to upload';
        }
        if (progressBar) {
            progressBar.style.width = '0%';
            progressBar.classList.remove('success');
        }
    }

    submit() {
        if (!this.options.validateStep(this.currentStep)) {
            return;
        }

        if (this.options.onSubmit) {
            this.options.onSubmit(this.uploadedFiles);
        }
    }

    getUploadedFiles() {
        return this.uploadedFiles;
    }
}

// Export for use
window.MobileFormWizard = MobileFormWizard;
