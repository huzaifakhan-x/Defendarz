   $(document).ready(function() {
            // Mobile Menu Toggle
            $('.mobile-toggle').click(function() {
                $('.nav-menu').toggleClass('active');
                $(this).find('i').toggleClass('fa-bars fa-times');
            });
            
            // Smooth Scrolling
            $('a[href*="#"]').on('click', function(e) {
                e.preventDefault();
                
                $('html, body').animate(
                    {
                        scrollTop: $($(this).attr('href')).offset().top - 80,
                    },
                    500,
                    'linear'
                );
                
                // Close mobile menu when clicking a link
                if ($('.nav-menu').hasClass('active')) {
                    $('.nav-menu').removeClass('active');
                    $('.mobile-toggle i').toggleClass('fa-bars fa-times');
                }
            });
            
            // Header scroll effect
            $(window).scroll(function() {
                if ($(this).scrollTop() > 100) {
                    $('header').addClass('scrolled');
                } else {
                    $('header').removeClass('scrolled');
                }
            });
            
            // Animation on scroll
            function animateOnScroll() {
                $('.animated').each(function() {
                    var position = $(this).offset().top;
                    var scrollPosition = $(window).scrollTop() + $(window).height() - 100;
                    
                    if (position < scrollPosition) {
                        $(this).css('opacity', '1');
                    }
                });
            }
            
            // Initial check
            animateOnScroll();
            
            // Check on scroll
            $(window).scroll(function() {
                animateOnScroll();
            });
            
            // Set active navigation link
            $(window).scroll(function() {
                var scrollDistance = $(window).scrollTop();
                
                $('section').each(function(i) {
                    if ($(this).position().top <= scrollDistance + 100) {
                        $('.nav-menu a.active').removeClass('active');
                        $('.nav-menu a').eq(i).addClass('active');
                    }
                });
            });
        });
    
        app.use(express.static('public'));
