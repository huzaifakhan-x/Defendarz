require('dotenv').config();

const isProduction = process.env.SERVER_TYPE === "PRODUCTION";
const FRONTEND_URL = isProduction ? process.env.LIVE_URL : process.env.LOCAL_URL;

module.exports = { isProduction, FRONTEND_URL };
