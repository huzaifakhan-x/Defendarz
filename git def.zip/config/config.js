const config = {
    "jwtPrivateKey":"cool_jwtPrivateKey",
    emailUser:"ayaanmughal18@gmail.com",
    emailPassword:"MUGHALMUGHAL"}