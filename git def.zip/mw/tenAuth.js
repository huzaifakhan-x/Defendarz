
const jwt= require('jsonwebtoken');

module.exports = function  (req, res , next){
   console.log("authenticating .... idhoooooo hi hoonn");
    const token = req.cookies.tenauthcookie;
   
    if (token) {
   try{
    console.log("m her")

    const verified= jwt.verify(token, process.env.JWT_PRIVATE_KEY);
    console.log(verified)
    console.log(verified.type)
    if (verified.type !== 'tenant') res.render('pages/tenantlogin',{err:"exp"});
    req.user= verified;
    console.log("next")
    next();
   }catch(err) {
      console.log("m her wth err")
      // res.clearCookie("authcookie");
      // res.clearCookie("admincookie");
      res.render('pages/tenantlogin',{err:"exp"});
    }
}
else{
   res.render('pages/tenantlogin',{err:"exp"});
       }
    }