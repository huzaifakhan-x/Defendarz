const {usvali} = require("../joi/joi.js")
const { db } = require('../firebase.js')
const bcrypt = require("bcrypt");
const jwt=  require('jsonwebtoken');

module.exports= async function(req, res, next){


       const uname = req.cookies.namecookie;
       console.log(uname);
    console.log("m here")
 const usersRef =  db.collection('users');
      const queryRef = await usersRef.where('uname', '==', uname ).get();
      // if (queryRef.empty)  return res.status(400).send("Invalid Email or password");
    
      if (queryRef.empty)  return  res.render('pages/signin', {err:"username"});
      const col= queryRef.docs.map((doc)=> ({id:doc.id, ...doc.data()}))

 
        
          const SP = col[0].CPOAN;

        console.log("SP",CPOAN)
         console.log('kiasdkihiflaoisdhf',CPOAN)
      if(CPOAN===false){
  console.log("next")
    next();

      }
else{
       res.redirect('/CPOAN' );
}


   
  



} 