const swal = require("sweetalert")
var flash = require('connect-flash');
module.exports= function(req, res, next){
    
    console.log("user");
    console.log(req.user);
    let isAdmin = req.user.isAdmin;
    console.log(isAdmin)
    // if (!req.user.isAdmin) return res.status(403).send('access denied');
    // return res.redirect(403, 'back');
    // return   res.send({ title: 'GeeksforGeeks' });
    // return res.status(403).redirect('back')
    // return res.redirect("back").with("Message","Admin not autorizwed")
    // return res.redirect('/api/prod/get',404,{
        //     error: "Permission Denied",
        // });
    //    res.cookie('admincookie',isAdmin,{maxAge:90000,httpOnly:true})
        if (!req.user.isAdmin){
     
       res.redirect('/api/prod/get');

        
    }else{ 
      
        next();             
    } 
    
}
