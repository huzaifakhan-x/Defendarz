const {usvali} = require("../joi/joi.js")
const { db } = require('../firebase.js')
const bcrypt = require("bcrypt");
const jwt=  require('jsonwebtoken');

module.exports= async function(req, res, next){


       const username = req.cookies.usernamecookie;
       console.log(username);
    console.log("m here")
 const usersRef =  db.collection('Applications');
      const queryRef = await usersRef.where('username', '==', username ).get();
      // if (queryRef.empty)  return res.status(400).send("Invalid Email or password");
    
      if (queryRef.empty)  return  res.render('pages/signin', {err:"username"});
      const col= queryRef.docs.map((doc)=> ({id:doc.id, ...doc.data()}))

          const NDC = col[0].NDC;
          const timeNdc = col[0].timeNdc;

        console.log("NDC",NDC)
         console.log('kiasdkihiflaoisdhf',NDC)
      if(NDC){

  console.log("next")
    next();

      }
else{
       res.render('pages/NDCN.ejs', { timeNdc: timeNdc  });
}


   
  



} 