  const jwt = require('jsonwebtoken');
  module.exports = function (req, res, next) {
        console.log("authenticating ....");
      console.log("Request query parameters:", req.query);
      // Extract token from query object keys
      const queryKeys = Object.keys(req.query);
      const token = queryKeys[0];
      if (queryKeys.length === 0) {
            console.log("No token provided in query parameters");
          return res.status(401).json({ success: "0", message: "No token provided" });
      }
      // The token is the first (and probably only) key in the query object
      else if (!token) {
            console.log("No token provided in query parameters");
          // return res.status(401).json({ success: "0", message: "No token provided" });
  res.send({"success":"1",data:data });
        }
      console.log("Extracted token:", token);
      try {
        console.log("HELOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
        const verified = jwt.verify(token, process.env.JWT_PRIVATE_KEY);
        console.log("HELOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
        req.user = verified; // Attach user data to request
          next(); // Proceed to next middleware/controller
      } catch (error) {
          console.error("Token verification failed:", error);
          return res.status(401).json({ success: "0", message: "Invalid token" });
      }
    next();
  }

      