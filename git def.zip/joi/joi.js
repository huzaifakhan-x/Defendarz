const Joi = require('joi');

function usvali(user){
  
    const schema=Joi.object({
         uname : Joi.string().min(4).max(255).required(),
         pass : Joi.string().min(4).max(255).required(),
         isAdmin : Joi.boolean(),
        
        
    })
    return schema.validate(user);
}

exports.usvali= usvali;