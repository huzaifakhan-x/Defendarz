const express = require('express');
const router = express.Router();


const {postadd} = require('../../controller/properties/postadd');
const {getallproperties}= require('../../controller/properties/getallproperties');
const {gethouses}= require('../../controller/properties/gethouses'); 
const {getflats} = require ('../../controller/properties/getflats');
const {getplots} = require('../../controller/properties/getplots'); 
const {getfiles} = require('../../controller/properties/getfiles')
const {getpropertybyid} = require('../../controller/properties/getpropertybyid')
const {getpropertiesbylocation} = require('../../controller/properties/getpropertiesbylocation')
const {getfeaturedproperties} = require('../../controller/properties/getfeaturedproperties')



router.get('/getall', getallproperties); // Get all properties
router.get('/gethouses', gethouses); // Get only houses
router.get('/getflats', getflats); // Get only flats/apartments
router.get('/getplots', getplots); // Get only plots
router.get('/getfiles', getfiles); // Get only files
router.get('/getfeatured', getfeaturedproperties); // Get featured properties
router.get('/getpropertybyid/:id', getpropertybyid); // Get property by ID
router.get('/getpropertiesbylocation/:location', getpropertiesbylocation); // Get properties by location

router.post('/postadd' , postadd);

module.exports = router;