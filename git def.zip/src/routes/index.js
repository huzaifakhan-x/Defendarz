const express = require('express');

const router = express.Router();

const services = require('./services');
const auth = require('./auth');
const properties = require('./properties');

router.use('/services', services);
router.use('/auth', auth);
router.use('/properties', properties);

module.exports = router;
