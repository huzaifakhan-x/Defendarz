const express = require('express');
const router = express.Router();

const {signup} = require('../../controller/auth/signup');
const {signout} = require('../../controller/auth/signout');
const {signin} = require('../../controller/auth/signin');

const {signin2} = require('../../controller/auth/signin2');
const {signin3} = require('../../controller/auth/signin3');
const {tenantsignup} = require('../../controller/auth/tenantsignup');
const {tenantlogin2} = require('../../controller/auth/tenantlogin2');
const {tenantlogin} = require('../../controller/auth/tenantlogin');
const {ownersignin} = require('../../controller/auth/ownersignin');
const {ownersignin2} = require('../../controller/auth/ownersignin2');
const {checkemail} = require('../../controller/auth/checkemail');
const {sendresetcode} = require('../../controller/auth/sendresetcode');
const {verifyresetcode} = require('../../controller/auth/verifyresetcode');
const {resetpassword} = require('../../controller/auth/resetpassword');


router.get('/ownersignin',ownersignin );
router.get('/tenantlogin', tenantlogin);
router.get('/signin', signin);
router.get('/logout', signout);
router.get('/tenantsignup', tenantsignup);


router.post('/reset-password', resetpassword);
router.post('/verify-reset-code', verifyresetcode);
router.post('/send-reset-code', sendresetcode);
router.post('/check-email', checkemail );
router.post('/signup', signup);
router.post('/signin', signin2);
router.post('/cpoa' , signin3 );
router.post('/ndc' , signin3 );
router.post('/ndcw' , signin3 );
router.post('/ndc' , signin3 );
router.post('/ot' , signin3 );
router.post('/lh' , signin3 );
router.post('/sp' , signin3 );
router.post('/poa' , signin3 );
router.post('/tenantsignup', tenantsignup);
router.post('/tenantlogin', tenantlogin2);
router.post('/ownersignin', ownersignin2);

module.exports = router;

