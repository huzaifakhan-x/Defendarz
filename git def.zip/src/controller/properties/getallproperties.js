const { db } = require('../../../firebase.js');

// Get all properties
exports.getallproperties = async (req, res) => {
    console.log('Fetching all properties...');
    
    try {
        const propertiesRef = db.collection('properties');
        const snapshot = await propertiesRef.get();
        
        const properties = [];
        snapshot.forEach(doc => {
            properties.push({
                id: doc.id,
                ...doc.data()
            });
        });
        
        console.log(`Found ${properties.length} properties`);
        
        res.status(200).json({
            success: true,
            message: 'Properties fetched successfully',
            data: properties
        });
        
    } catch (error) {
        console.error('Error fetching properties:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching properties',
            error: error.message
        });
    }
};
