const { db } = require('../../../firebase.js');

// Get properties by location
exports.getpropertiesbylocation = async (req, res) => {
    console.log('Fetching properties by location...');
    
    try {
        const { location } = req.params;
        
        if (!location) {
            return res.status(400).json({
                success: false,
                message: 'Location is required'
            });
        }
        
        const propertiesRef = db.collection('properties');
        const snapshot = await propertiesRef.where('address', '>=', location).get();
        
        const properties = [];
        snapshot.forEach(doc => {
            const propertyData = doc.data();
            if (propertyData.address.toLowerCase().includes(location.toLowerCase())) {
                properties.push({
                    id: doc.id,
                    ...propertyData
                });
            }
        });
        
        console.log(`Found ${properties.length} properties in ${location}`);
        
        res.status(200).json({
            success: true,
            message: 'Properties fetched successfully',
            data: properties
        });
        
    } catch (error) {
        console.error('Error fetching properties by location:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching properties by location',
            error: error.message
        });
    }
};