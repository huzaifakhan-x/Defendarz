const { db } = require('../../../firebase.js');

// Get flats/apartments only
exports.getflats = async (req, res) => {
    console.log('Fetching flats/apartments...');
    
    try {
        const propertiesRef = db.collection('properties');
        const snapshot = await propertiesRef.where('type', '==', 'flat').get();
        
        const properties = [];
        snapshot.forEach(doc => {
            properties.push({
                id: doc.id,
                ...doc.data()
            });
        });
        
        console.log(`Found ${properties.length} flats/apartments`);
        
        res.status(200).json({
            success: true,
            message: 'Flats fetched successfully',
            data: properties
        });
        
    } catch (error) {
        console.error('Error fetching flats:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching flats',
            error: error.message
        });
    }
};