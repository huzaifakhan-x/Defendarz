const { db } = require('../../../firebase.js');

// Get plots only
exports.getplots = async (req, res) => {
    console.log('Fetching plots...');
    
    try {
        const propertiesRef = db.collection('properties');
        const snapshot = await propertiesRef.where('type', '==', 'plot').get();
        
        const properties = [];
        snapshot.forEach(doc => {
            properties.push({
                id: doc.id,
                ...doc.data()
            });
        });
        
        console.log(`Found ${properties.length} plots`);
        
        res.status(200).json({
            success: true,
            message: 'Plots fetched successfully',
            data: properties
        });
        
    } catch (error) {
        console.error('Error fetching plots:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching plots',
            error: error.message
        });
    }
};