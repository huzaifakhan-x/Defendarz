const { db } = require('../../../firebase.js');

// Get featured properties
exports.getfeaturedproperties = async (req, res) => {
    console.log('Fetching featured properties...');
    
    try {
        const propertiesRef = db.collection('properties');
        const snapshot = await propertiesRef.limit(10).get(); // Get first 10
        
        const properties = [];
        snapshot.forEach(doc => {
            properties.push({
                id: doc.id,
                ...doc.data()
            });
        });
        
        console.log(`Found ${properties.length} featured properties`);
        
        res.status(200).json({
            success: true,
            message: 'Featured properties fetched successfully',
            data: properties
        });
        
    } catch (error) {
        console.error('Error fetching featured properties:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching featured properties',
            error: error.message
        });
    }
};