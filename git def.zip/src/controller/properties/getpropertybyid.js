
const { db } = require('../../../firebase.js');

// Get property by ID
exports.getpropertybyid = async (req, res) => {
    console.log('Fetching property by ID...');
    
    try {
        const { id } = req.params;
        
        if (!id) {
            return res.status(400).json({
                success: false,
                message: 'Property ID is required'
            });
        }
        
        const propertyRef = db.collection('properties').doc(id);
        const doc = await propertyRef.get();
        
        if (!doc.exists) {
            return res.status(404).json({
                success: false,
                message: 'Property not found'
            });
        }
        
        const property = {
            id: doc.id,
            ...doc.data()
        };
        
        console.log(`Found property: ${property.title}`);
        
        res.status(200).json({
            success: true,
            message: 'Property fetched successfully',
            data: property
        });
        
    } catch (error) {
        console.error('Error fetching property:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching property',
            error: error.message
        });
    }
};