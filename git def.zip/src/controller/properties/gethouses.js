const { db } = require('../../../firebase.js');

exports.gethouses = async (req, res) => {
    console.log('Fetching houses...');
    
    try {
        const propertiesRef = db.collection('properties');
        const snapshot = await propertiesRef.where('type', '==', 'house').get();

        const properties = [];
        snapshot.forEach(doc => {
            properties.push({
                id: doc.id,
                ...doc.data()
            });
        });
        
        console.log(`Found ${properties.length} houses`);
        
        res.status(200).json({
            success: true,
            message: 'Houses fetched successfully',
            data: properties
        });
        
    } catch (error) {
        console.error('Error fetching houses:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching houses',
            error: error.message
        });
    }
};