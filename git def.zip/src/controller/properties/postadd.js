const { db } = require('../../../firebase.js');

exports.postadd = async (req, res) => {
    console.log('I am in api .......POSTADDS');
    console.log(req.body);
      const propertyData = {
                    title: req.body.title,
                    type: req.body.type,
                    size: req.body.size,
                    address: req.body.address,
                    price: req.body.price,
                    priceNegotiable: req.body.priceNegotiable,
                    description: req.body.description,
                    features: req.body.features,
                    ownerName: req.body.ownerName,
                    ownerPhone: req.body.ownerPhone,
                    ownerEmail: req.body.ownerEmail,
                    images: req.body.images,
                    specifications: req.body.specifications,
                    listedBy:   req.body.listedBy,
                    currency: 'PKR',
                    
                };
        try {
        
                const collectionRef = db.collection('properties');
        const propDocRef = collectionRef.doc(propertyData.title);
        
        const existingDoc = await propDocRef.get();

        if (existingDoc.exists) {
            // COMPLETELY REPLACE THE EXISTING DOCUMENT
            await propDocRef.set(propertyData);
            console.log(`Here%%%%%%%%%%%%%%`);
        } else {
            // Create new document
            await propDocRef.set(propertyData);
            console.log(`There####################`);
        }

        // Get the updated document
        const updatedProp = await propDocRef.get();

        // Send ONE response
        res.status(200).json({
            success: true,
            message: 'Bill uploaded successfully',
            data: {
                id: updatedProp.id,
                ...updatedProp.data()
            }
        });

    } catch (error) {
        console.error('Error uploading bill:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error.message
        });
    }
      
}