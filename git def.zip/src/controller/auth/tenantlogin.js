exports.tenantlogin=(req, res)=> {

    res.render('pages/tenantlogin' ,{err:"norm"} );
  }