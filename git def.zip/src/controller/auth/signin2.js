const {usvali} = require("../../../joi/joi")
const { db } = require('../../../firebase.js')
const bcrypt = require("bcrypt");
const jwt=  require('jsonwebtoken');

exports.signin2= async(req, res) => {
      console.log("login controler");

      const {error} = usvali(req.body);
      if (error) return res.status(400).send(error.details[0].message);
      
      const uname = req.body.uname;
      const password = req.body.pass;
          
      const usersRef =  db.collection('users');
      const queryRef = await usersRef.where('uname', '==', uname ).get();
      // if (queryRef.empty)  return res.status(400).send("Invalid Email or password");
    
      if (queryRef.empty)  return  res.render('pages/signin', {err:"username"});
    
          const col= queryRef.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
  
      const validPassword = await bcrypt.compare(password, dPass)
      if (!validPassword) return  res.render('pages/signin', {err:"pass"});
      
      const isAdmin= col[0].isAdmin;

      const token =jwt.sign({id:dId,isAdmin:isAdmin},process.env.jwtPrivateKey, {expiresIn:'1h'});
 
        const dId = col[0].id;
          const dPass= col[0].pass;
        
      res.cookie('authcookie',token)
      res.cookie('admincookie',isAdmin)
      res.cookie('namecookie',uname)
      
      if (token){
        console.log("one...........")
        res.render('pages/index' );
        }
        else{
          console.log("2nd")
          res.redirect('/api/auth/signin' );
        }
      }