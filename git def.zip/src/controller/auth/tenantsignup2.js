const { db } = require('../../../firebase.js')

exports.tenantsignup =  async (req, res) => {
console.log("i am here in tenant signup.....");
console.log(req.body);
        const email =  req.body.email;
        const username = req.body.username;
        const location = req.body.location;
        const password = req.body.password;
        const rent = req.body.rent;
      const verificationToken  =  req.body.verificationToken;
function generateAvatar(name) {
    // Split the name into wordss
    const words = name.split(' ');
    // Get the first character of each word
    const initials = words.map(word => word.charAt(0).toUpperCase()).join('');
    return initials;
}
const avatar = generateAvatar(username);
           const ownerEmail = req.cookies.emailcookie;
                            console.log('i am here 3');
                           const now = new Date();
                                      const applyTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); 
                  console.log('Here')           
                   await db.collection('users').doc(email).set({           
                  property: location,
                  username ,
                  password,
                  ownerEmail,
                  rent,
                  avatar,
                  tenantEmail: email,
                  monthlyDate: 10,
                  registeredAt:now,
                  time: applyTime,
                  name : username, 
                  type:'tenant',
                     verificationToken:  verificationToken,
                        tenantEmail  : email,
                      tenantCnicFront: req.body.tenantCnicFront,
                      tenantCnicBack: req.body.tenantCnicBack,
                      rentalAgreement: req.body.rentalAgreement,
                  });
                  console.log('Here')
                
                  res.status(200).json({ message: 'TENANT Added' , });
                }
              