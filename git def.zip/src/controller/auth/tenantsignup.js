const { db } = require('../../../firebase.js')

const nodemailer2 = require("nodemailer");

exports.tenantsignup =  async (req, res) => {
    console.log("i am here in tenant signup.....");
    console.log(req.body);

    const email =  req.body.email;
    const username = req.body.username.toLowerCase();
    const location = req.body.location;
    const password = req.body.password;
    const rent = req.body.rent;
    const due = req.body.due;

    function generateAvatar(name) {
        const words = name.split(' ');
        const initials = words.map(word => word.charAt(0).toUpperCase()).join('');
        return initials;
    }
    const avatar = generateAvatar(username);

    const ownerEmail = req.cookies.emailcookie;
    const ownerId = req.cookies.idcookie;
    console.log('i am here 3');
    const now = new Date();
    const applyTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const verificationToken = req.body.verificationToken; // Get from frontend

    // Prepare user data object
    const userData = {
        ownerId,
        propertyAddress: location,
        username,
        // password,
        ownerEmail,
        rent,
        avatar,
        tenantEmail: email,
        registeredAt: now,
        time: applyTime,
        name: username,
        type: 'tenant',
        verificationToken, // <-- Save the token
        verified: false,   // <-- Save verified status
        tenantCnicFront: req.body.tenantCnicFront,      // <-- Add this
        tenantCnicBack: req.body.tenantCnicBack,        // <-- Add this
        rentalAgreement: req.body.rentalAgreement,       // <-- Add this
        status: 'pending',
        createdAt: applyTime,
        RentDueDate : due,
        otherDue : 20
    };

    // Remove undefined fields
  
  await  db.collection('users').doc(email).set(userData);

    // Prepare docs data object

   console.log("i am hereeeeeeeeeeeeeeeeeee in mailer2");
console.log(req.body.email);

const token = req.body.verificationToken;
console.log('Token',token);
  const usersRef =  db.collection('users');
   const queryRef = await usersRef.where('email', '==', email && 'type' == 'tenant'  ).get();
      if (!queryRef.empty)   {
        console.log('i am here');
          res.status(400).json({ 
  error: "Email already exists",
  redirect: "/sign" 
});
      }
else{
  const transpoter = nodemailer2.createTransport({ 
            host:'smtp.gmail.com',
             port:587,
             secure:false,
             requireTLS:true,
             auth:{
                 user:'ayaanmughal18@gmail.com',
                 pass:'yvscdczabngzksft'
             }
         });
              const mailOptions = {
          from: 'ayaanmughal18@gmail.com',
          to: email,
          subject: "Verify Your Documents",
          html: `<p>Hiii ${username} tenant Please click the Link <a href="${process.env.SERVER_TYPE === "STAGING" ? process.env.LOCAL_URL : process.env.LIVE_URL}/tenantverification?token=${token}">to shake hand.</a> </p>`
      }
      console.log(mailOptions);
         transpoter.sendMail(mailOptions, function(error , info){
                if(error){
                 console.log(error);
                }
                 else{
                     console.log("Mail has been sent:-" , info.response)
                 }
         }) 
          res.status(200).json({ message: "Email sent Successfully" } );
     }
}