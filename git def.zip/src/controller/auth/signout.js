

exports.signout= async(req, res) => {
      console.log("logout controler");

       res.clearCookie('authcookie');
       res.clearCookie('admincookie');
       res.redirect('/api/prod/get' );
      }