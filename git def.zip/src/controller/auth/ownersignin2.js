const { usvali } = require("../../../joi/joi")
const { db } = require('../../../firebase.js')
const bcrypt = require("bcrypt");
const jwt = require('jsonwebtoken');

// Manual rate limiting implementation
const loginAttempts = new Map();
const RATE_LIMIT = {
    WINDOW_MS: 15 * 60 * 1000, // 15 minutes
    MAX_ATTEMPTS: 5, // Max 5 attempts per window
    BLOCK_TIME: 30 * 60 * 1000 // 30 minutes block after max attempts
};

function checkRateLimit(ip) {
    const now = Date.now();
    const userAttempts = loginAttempts.get(ip) || { count: 0, firstAttempt: now, lastAttempt: now, blockedUntil: 0 };
    
    // Reset if window has passed
    if (now - userAttempts.firstAttempt > RATE_LIMIT.WINDOW_MS) {
        userAttempts.count = 0;
        userAttempts.firstAttempt = now;
    }
    
    // Check if user is blocked
    if (userAttempts.blockedUntil > now) {
        const remainingTime = Math.ceil((userAttempts.blockedUntil - now) / 1000 / 60);
        throw new Error(`Too many login attempts. Try again in ${remainingTime} minutes.`);
    }
    
    // Check if user exceeded max attempts
    if (userAttempts.count >= RATE_LIMIT.MAX_ATTEMPTS) {
        userAttempts.blockedUntil = now + RATE_LIMIT.BLOCK_TIME;
        loginAttempts.set(ip, userAttempts);
        const remainingTime = Math.ceil(RATE_LIMIT.BLOCK_TIME / 1000 / 60);
        throw new Error(`Too many login attempts. Account temporarily locked for ${remainingTime} minutes.`);
    }
    
    // Increment attempt count
    userAttempts.count++;
    userAttempts.lastAttempt = now;
    loginAttempts.set(ip, userAttempts);
    
    return userAttempts.count;
}

function resetRateLimit(ip) {
    loginAttempts.delete(ip);
}

// Clean up old entries every hour
setInterval(() => {
    const now = Date.now();
    for (const [ip, attempts] of loginAttempts.entries()) {
        if (now - attempts.lastAttempt > 24 * 60 * 60 * 1000) { // 24 hours
            loginAttempts.delete(ip);
        }
    }
}, 60 * 60 * 1000);

exports.ownersignin2 = async (req, res) => {
    const clientIP = req.ip || req.connection.remoteAddress;
    
    try {
        // Check rate limit
        const attempts = checkRateLimit(clientIP);
        
        console.log("🔐 Owner login attempt:", {
            ip: clientIP,
            attempts,
            timestamp: new Date().toISOString()
        });

        // Input validation
        const { error } = usvali(req.body);
        if (error) {
            console.warn("❌ Validation failed:", error.details[0].message);
            return res.status(400).json({
                success: "2", // Validation errors
                message: error.details[0].message
            });
        }

        const uname = req.body.uname.toLowerCase().trim();
        const password = req.body.pass;

        // Find user in database
        const usersRef = db.collection('users');
        const queryRef = await usersRef
            .where('username', '==', uname)
            .get();

        if (queryRef.empty) {
            console.warn("❌ User not found:", uname);
            // Don't reveal whether user exists for security
            await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));
            return res.status(401).json({
                success: "3", // User not found
                err: "user_not_found",
                message: "Username not found. Please check your username or sign up for a new account."
            });
        }

        const userDoc = queryRef.docs[0];
        const userData = { id: userDoc.id, ...userDoc.data() };

        // Verify password
        const validPassword = await bcrypt.compare(password, userData.password);
        
        // Always use same delay regardless of password validity for security
        await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 500));

        if (!validPassword) {
            console.warn("❌ Invalid password for user:", uname);
            return res.status(401).json({
                success: "4", // Invalid password
                err: "invalid_password",
                message: "Incorrect password. Please try again or click 'Forgot Password' to reset it.",
                remainingAttempts: RATE_LIMIT.MAX_ATTEMPTS - attempts
            });
        }

        // Reset rate limit on successful login
        resetRateLimit(clientIP);

        // Generate JWT token
        const token = jwt.sign(
            {
                id: userData.id,
                isAdmin: userData.isAdmin || false,
                type: userData.type,
                username: userData.username,
                email: userData.email
            },
            process.env.JWT_PRIVATE_KEY,
            { 
                expiresIn: process.env.JWT_EXPIRES_IN || '1h'
            }
        );

        // Prepare response data - MATCHING FRONTEND EXPECTATIONS
        const responseData = {
            token: token,
            email: userData.email,
            dId: userData.id,
            type: userData.type,
            uname: userData.username
        };

        // Set secure headers
        res.setHeader("Access-Control-Allow-Credentials", "true");
        res.setHeader("Access-Control-Allow-Origin", process.env.LIVE_URL);
        res.setHeader("X-Content-Type-Options", "nosniff");
        res.setHeader("X-Frame-Options", "DENY");
        res.setHeader("X-XSS-Protection", "1; mode=block");

        // Log successful login
        console.log("✅ Login successful for user:", uname, "ID:", userData.id);

        return res.status(200).json({
            success: "1", // Success remains "1"
            data: responseData
        });

    } catch (error) {
        console.error('💥 Error in ownersignin2:', {
            error: error.message,
            ip: clientIP,
            timestamp: new Date().toISOString()
        });

        if (error.message.includes('Too many login attempts')) {
            return res.status(429).json({
                success: "5", // Rate limit errors
                err: "rate_limit",
                message: error.message
            });
        }

        return res.status(500).json({
            success: "6", // Server errors
            err: "server_error",
            message: "An internal server error occurred"
        });
    }
};

// Helper functions
async function trackFailedAttempt(userId, ip) {
    try {
        // Implement your failed attempt tracking logic here
        // This could update a counter in your database
        const failedAttemptsRef = db.collection('login_attempts').doc();
        await failedAttemptsRef.set({
            userId,
            ip,
            timestamp: new Date().toISOString(),
            type: 'failed'
        });
        console.log(`Failed login attempt for user ${userId} from IP ${ip}`);
    } catch (error) {
        console.error('Error tracking failed attempt:', error);
    }
}

async function resetFailedAttempts(userId) {
    try {
        // Reset failed attempt counter in database
        console.log(`Resetting failed attempts for user ${userId}`);
    } catch (error) {
        console.error('Error resetting failed attempts:', error);
    }
}

function generateSessionId() {
    return require('crypto').randomBytes(32).toString('hex');
}

// Token verification middleware (for future use)
exports.verifyToken = async (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        
        if (!token) {
            return res.status(401).json({
                success: "7", // Missing token
                err: "token_missing"
            });
        }

        const decoded = jwt.verify(token, process.env.JWT_PRIVATE_KEY);
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(401).json({
            success: "8", // Invalid token
            err: "token_invalid"
        });
    }
};

// Export rate limit functions for testing/management
exports.getRateLimitInfo = (ip) => loginAttempts.get(ip);
exports.clearRateLimit = (ip) => loginAttempts.delete(ip);