const { db } = require('../../../firebase.js');
const nodemailer = require("nodemailer");

// Store verification codes temporarily (in production, use Redis or database)
const verificationCodes = new Map();

exports.sendresetcode = async (req, res) => {
    console.log("i am in reset code");
    const email = req.body.email;
    const code = req.body.code;
    
    console.log("Email:", email);
    console.log("Code:", code);
    
    // Store the code for verification (with 10-minute expiry)
    verificationCodes.set(email, {
        code: code,
        expires: Date.now() + 10 * 60 * 1000 // 10 minutes
    });

    const transporter = nodemailer.createTransport({ 
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        requireTLS: true,
        auth: {
            user: 'ayaanmughal18@gmail.com',
            pass: 'yvscdczabngzksft'
        }
    });

    const mailOptions = {
        from: 'ayaanmughal18@gmail.com',
        to: email,
        subject: "Password Reset Verification Code",
        html: `<h1>DefendArz.com</h1>
               <p>Your verification code for password reset is: <strong>${code}</strong></p>
               <p>This code will expire in 10 minutes.</p>`
    };

    console.log(mailOptions);
    
    try {
        await transporter.sendMail(mailOptions);
        console.log("Mail has been sent");
        
        // Save verification code to Firestore
        const usersRef = db.collection('users');
        const querySnapshot = await usersRef.where('tenantEmail', '==', email).where('type', '==', 'tenant').get();

        if (querySnapshot.empty) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        // Update all matching documents with verification code
        const batch = db.batch();
        const expirationTime = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes from now
        
        querySnapshot.forEach(doc => {
            const userRef = usersRef.doc(doc.id);
            batch.update(userRef, {
                resetPasswordCode: code,
                resetPasswordCodeExpires: expirationTime,
                codeGeneratedAt: new Date()
            });
        });

        await batch.commit();
        console.log("Verification code saved to Firestore for email:", email);
        
        res.json({ success: true, message: 'Verification code sent successfully' });
    } catch (error) {
        console.log("Error:", error);
        res.status(500).json({ success: false, message: 'Failed to send verification code' });
    }
};
