const { db } = require('../../../firebase.js')

exports.tenantsignup =  async (req, res) => {
    console.log("i am here in tenant signup.....");
    console.log("i am here in tenant signup.....");

    console.log(req.body);

    const email =  req.body.email;
    const username = req.body.username;
    const location = req.body.location;
    const password = req.body.password;
    const rent = req.body.rent;

    function generateAvatar(name) {
        const words = name.split(' ');
        const initials = words.map(word => word.charAt(0).toUpperCase()).join('');
        return initials;
    }
    const avatar = generateAvatar(username);

    const ownerEmail = req.cookies.emailcookie;
    console.log('i am here 3');
    const now = new Date();
    const applyTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const verificationToken = req.body.verificationToken; // Get from frontend

    // Prepare user data object
    const userData = {
        property: location,
        username,
        password,
        ownerEmail,
        rent,
        avatar,
        tenantEmail: email,
        monthlyDate: 10,
        registeredAt: now,
        time: applyTime,
        name: username,
        type: 'tenant',
        verificationToken, // <-- Save the token
        verified: false,   // <-- Save verified status
        tenantCnicFront: req.body.tenantCnicFront,      // <-- Add this
        tenantCnicBack: req.body.tenantCnicBack,        // <-- Add this
        rentalAgreement: req.body.rentalAgreement       // <-- Add this
    };

    // Remove undefined fields
  
    await db.collection('users').doc(email).set(userData);

    // Prepare docs data object
    const docsData = {
        tenantEmail: email,
        tenantCnicFront: req.body.tenantCnicFront,
        tenantCnicBack: req.body.tenantCnicBack,
        rentalAgreement: req.body.rentalAgreement
    };

  

    await db.collection('users').doc('Docs').set(docsData);

    res.status(200).json({ message: 'TENANT Added' });
}


