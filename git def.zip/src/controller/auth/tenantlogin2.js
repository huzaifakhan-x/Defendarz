const { db } = require('../../../firebase.js')
const jwt =  require('jsonwebtoken');
const isProduction = process.env.SERVER_TYPE === "PRODUCTION";
const bcrypt = require("bcrypt");

exports.tenantlogin2 =  async (req, res) => {
console.log("i am here in tenant Login.....");

        const username = req.body.username.toLowerCase() ;
        const pass = req.body.password;
        console.log(username);
        console.log(pass);

      const usersRef =  db.collection('users');
      const queryRef = await usersRef.where('username','==', username ).where('type', '==', 'tenant').get();
   
        if (queryRef.empty)  return  res.render('pages/tenantlogin', {err:"username"});
       if (!queryRef.empty)  {

          const col= queryRef.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
          const password= col[0].password;
          console.log(password);
          const  ownerEmail = col[0].ownerEmail;
          console.log(password);
          const id = col[0].id;
          const avatar = col[0].avatar;
         
          const tenantEmail = col[0].tenantEmail;
          const rentDueDate = col[0].RentDueDate;
          const type = col[0].type;
          const validPassword = await bcrypt.compare(pass, password);
          
          if(!validPassword) return  res.render('pages/tenantlogin', {err:"password"});
          
            const token =jwt.sign({id:id , type:type},process.env.JWT_PRIVATE_KEY, {expiresIn:'1h'});

          if (token){
              var data = {
                username,
                token,
                tenantEmail,
                type,
                avatar, 
                ownerEmail,
                id, 
                rentDueDate,
                
              }

            console.log("✅ Login success, cookies set!");
              console.log("one...........");
              res.send({"success":"1",data:data });
              }
              else{
                console.log("2nd");
                res.redirect('/api/auth/tenantlogin' );
              }                          
}
}