const { db } = require('../../../firebase')
const bcrypt = require("bcrypt");
exports.resetpassword = async (req, res) => {
    console.log("i am in reset password");
    const { email, newPassword } = req.body;
    
    console.log("Password reset request - Email:", email);
    
    try {
        // Validate input
        if (!email || !newPassword) {
            return res.status(400).json({ 
                success: false, 
                message: 'Email and new password are required' 
            });
        }

        if (newPassword.length < 6) {
            return res.status(400).json({ 
                success: false, 
                message: 'Password must be at least 6 characters long' 
            });
        }

        // Find the user
        const usersRef = db.collection('users');
        const querySnapshot = await usersRef
            .where('tenantEmail', '==', email)
            .where('type', '==', 'tenant')
            .get();

        if (querySnapshot.empty) {
            return res.status(404).json({ 
                success: false, 
                message: 'User not found' 
            });
        }

        const userDoc = querySnapshot.docs[0];

        // Hash the new password
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(newPassword, saltRounds);

        // Update the user's password and clear any reset fields
        await usersRef.doc(userDoc.id).update({
            password: hashedPassword,
            resetPasswordCode: null,
            resetPasswordCodeExpires: null,
            isCodeVerified: null,
            codeVerifiedAt: null,
            passwordLastChanged: new Date()
        });

        console.log("Password reset successfully for email:", email);

        return res.json({ 
            success: true, 
            message: 'Password reset successfully! You can now log in with your new password.' 
        });

    } catch (error) {
        console.log("Error resetting password:", error);
        return res.status(500).json({ 
            success: false, 
            message: 'Error resetting password. Please try again.' 
        });
    }
};