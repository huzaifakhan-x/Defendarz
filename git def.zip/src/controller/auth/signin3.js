const {usvali} = require("../../../joi/joi")
const { db } = require('../../../firebase.js')
const bcrypt = require("bcrypt");
const jwt=  require('jsonwebtoken');

exports.signin3= async(req, res) => {
  console.log("Data Collecting................signin3");
  console.log(req.body);

        //  const {error} = usvali(req.body);
        //  if (error) return res.status(400).send(error.details[0].message);
         const uname = req.body.uname;
         console.log(uname);
         const password = req.body.pass;
         const usersRef =  db.collection('users');
         const queryRef = await usersRef.where('username', '==', uname ).get();
         if (queryRef.empty)  return  res.render('pages/signin', {err:"username"});
          const col= queryRef.docs.map((doc)=> ({id:doc.id, ...doc.data()}));
          console.log(col);
          const dId = col[0].id;
          const dPass= col[0].password;
          const email= col[0].email;
         const validPassword = await bcrypt.compare(password, dPass);
         if (!validPassword) return  res.render('pages/signin', {err:"pass"});
         const isAdmin= col[0].isAdmin;
         const token =jwt.sign({id:dId,isAdmin:isAdmin},process.env.jwtPrivateKey, {expiresIn:'1h'});

         res.cookie('emailcookie',email)
         res.cookie('authcookie',token)
         res.cookie('admincookie',isAdmin)   
         res.cookie('namecookie',uname)
  
         if (token){
           console.log("one...........")
           res.render('pages/index' );
           }
           else{   
             console.log("2nd")
             res.redirect('/api/auth/signin' );
           }
      };