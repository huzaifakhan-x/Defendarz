exports.signin=(req, res)=> {

    res.render('pages/signin' ,{err:"norm"});
  }