
const { db } = require('../../../firebase.js')
exports.checkemail = async (req, res) => {
  try {
    console.log("i am Here ***************");
    console.log(req.body.email);
    
    const  email  = req.body.email;
    
    if (!email) {
      return res.status(400).json({
        success: false,
        error: 'Email is required'
      });
    }

    const usersRef = db.collection('users');
    // Fixed the query - you had a syntax error in the where clause
    const queryRef = await usersRef.where('tenantEmail', '==', email).where('type', '==', 'tenant').get();
    
    if (!queryRef.empty) {
      console.log('Email found in system');
      // Return success: true since email exists (for password reset flow)
      return res.status(200).json({
        success: true,
        message: 'Email found in system'
      });
    } else {
      console.log('Email not found in system');
      // Return success: false since email doesn't exist
      return res.status(200).json({
        success: false,
        error: 'Email not found in our system'
      });
    }
    
  } catch (error) {
    console.error('Error checking email:', error);
    return res.status(500).json({
      success: false,
      error: 'Error checking email. Please try again.'
    });
  }
};