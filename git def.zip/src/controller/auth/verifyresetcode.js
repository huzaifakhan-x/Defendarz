const { db } = require('../../../firebase.js');

exports.verifyresetcode = async (req, res) => {
    console.log("i am in verify reset code");
    const { email, code } = req.body;
    
    console.log("Verification request - Email:", email, "Code:", code);

    try {
        // Check Firestore for the verification code
        const usersRef = db.collection('users');
        const querySnapshot = await usersRef
            .where('tenantEmail', '==', email)
            .where('type', '==', 'tenant')
            .where('resetPasswordCode', '==', code)
            .get();

        if (querySnapshot.empty) {
            return res.json({ 
                success: false, 
                message: 'Invalid verification code or email' 
            });
        }

        const userDoc = querySnapshot.docs[0];
        const userData = userDoc.data();
        
        // Check if code has expired
        if (userData.resetPasswordCodeExpires && userData.resetPasswordCodeExpires.toDate() < new Date()) {
            // Remove expired code
            await usersRef.doc(userDoc.id).update({
                resetPasswordCode: null,
                resetPasswordCodeExpires: null
            });
            
            return res.json({ 
                success: false, 
                message: 'Verification code has expired' 
            });
        }

        // Code is valid - clear it from Firestore so it can't be reused
        await usersRef.doc(userDoc.id).update({
            resetPasswordCode: null,
            resetPasswordCodeExpires: null,
            isCodeVerified: true, // Optional: Add a flag to mark code as verified
            codeVerifiedAt: new Date() // Optional: Track when code was verified
        });

        return res.json({ 
            success: true, 
            message: 'Code verified successfully' 
        });
    } catch (error) {
        console.log("Error verifying code:", error);
        return res.status(500).json({ 
            success: false, 
            message: 'Error verifying code' 
        });
    }
};