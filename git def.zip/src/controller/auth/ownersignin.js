exports.ownersignin=(req, res)=> {

    res.render('pages/ownersignin' ,{err:"norm"});
  }