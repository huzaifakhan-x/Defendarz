const { db } = require('../../../firebase.js')
const bcrypt = require("bcrypt");
const jwt = require('jsonwebtoken');

exports.signup = async (req, res) => {
    try {
        console.log("i am here in signup.....");
        console.log(req.body);

        // Validate JWT secret key
        if (!process.env.JWT_PRIVATE_KEY) {
            throw new Error('JWT private key is not configured');
        }

        const { 
            password, 
            email, 
            username, 
            cnicFront, 
            cnicBack, 
            allotmentLetter, 
            sitePlan, 
            completionCertificate, 
            registeredAt,
            isAdmin = false 
        } = req.body;

        // Validate required fields
        if (!password || !email || !username) {
            return res.status(400).json({
                error: 'Missing required fields: password, email, username'
            });
        }

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Create user document
        await db.collection('users').doc(email).set({
            username: username.toLowerCase(),
            password: hashedPassword, 
            type: 'Owner',
            email: email,
            isAdmin: isAdmin,
            createdAt: new Date()
        });

        // Create application document with email as ID
        await db.collection('Applications').doc(email).set({
            username: username.toLowerCase(),
            email: email,
            ndcAttemptNo: 0, 
            spAttemptNo: 0,
            otAttemptNo: 0,
            poaAttemptNo: 0,
            lhAttemptNo: 0,
            cnicFront: cnicFront || null,
            cnicBack: cnicBack || null,
            allotmentLetter: allotmentLetter || null,
            sitePlan: sitePlan || null,
            completionCertificate: completionCertificate || null,
            registeredAt: registeredAt || null,
            status: 'pending',
            createdAt: new Date()
        });

        // Generate JWT token
        const token = jwt.sign(
            { 
                email: email, 
                username: username, 
                isAdmin: isAdmin 
            }, 
            process.env.JWT_PRIVATE_KEY, 
            { expiresIn: '1h' }
        );

        console.log('User added successfully');

        // Return success response
        return res.status(201).json({
            message: 'User registered successfully',
            token: token,
            user: {
                email: email,
                username: username,
                isAdmin: isAdmin
            }
        });

    } catch (error) {
        console.error('Signup error:', error);
        
        if (error.message.includes('JWT private key is not configured')) {
            return res.status(500).json({
                error: 'Server configuration error'
            });
        }

        return res.status(500).json({
            error: 'Internal server error during signup'
        });
    }
}