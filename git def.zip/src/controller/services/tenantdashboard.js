exports.tenantdashboard=(req, res)=> {
const id = req.cookies.idcookie;
const avatar = req.cookies.avatar;
const myName = req.cookies.namecookie;
const myEmail = req.cookies.tenantemail;
const ownerEmail = req.cookies.owneremail;
const due = req.cookies.duecookie;

    res.render('pages/tenantdashboard',{id , avatar, myName , myEmail, ownerEmail , due} );
  }
  exports.tenantdashboard2 = (req, res) => {
    console.log("=== Tenant DASHBOARD ROUTE HIT ==="); 
    console.log("D22222222222222222");
    console.log("Request method:", req.method);
    console.log("Request body data:", req.body); 
  const token = req.body.token;
  console.log(token);

    if (!token) {
        console.log("No token provided in request body");
        return res.send({"success":"0"});
    }
    if (req.body.type != "tenant") {
        console.log('not a tenant');
       return res.send({"success":"0"});
    }
    const isAjax = req.xhr || (req.headers.accept && req.headers.accept.indexOf('json') > -1);
    console.log("Is AJAX request:", isAjax);
    
    if (isAjax) {
        console.log("i am here AJax .,.....");
        console.log("i am here ");
        console.log("✅ Processing AJAX request with data:", req.body);
        return res.json({"success": "1", "receivedData": req.body});
    } else {
        console.log("✅ Rendering page");
        res.render('pages/dashboard', { 
            loggedInOwnerId: req.user ? req.user.id : "", 
            name: req.user ? req.user.name : "" 
        });
    }
};