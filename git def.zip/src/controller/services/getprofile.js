// controllers/profileController.js - Minimal version
const { db } = require('../../../firebase.js')

// GET Profile endpoint (Minimal)
exports.getprofile = async (req, res) => {
  try {
    console.log('GET PROFILE REQ HEADERS:', req.headers);

    const ownerId = req.headers.ownerid;

    console.log('OWNER ID:', ownerId);

    if (!ownerId && !email) {
      return res.status(400).json({ success: false, message: 'Missing parameters' });
    }
    
    let profile;
    
    // Find profile
    if (ownerId) {
      const doc = await db.collection('users').doc(ownerId).get();
      console.log('data', doc.data());


      
      if (doc.exists) profile = { id: doc.id, ...doc.data() };
    }
    console.log('PROFILE BY OWNER ID:', profile);
    
    
    if (!profile) {
      return res.status(404).json({ success: false, message: 'Profile not found' });
    }
    
    res.json({
      success: true,
      profile: {
        id: profile.id,
        name: profile.username || 'User',
        email: profile.email,
        firstName: profile.firstName || profile.name?.split(' ')[0] || 'User',
        phone: profile.phone || '',
        address: profile.address || '',
        memberSince: getMemberSince(profile.createdAt)
      }
    });
    
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
    function getMemberSince(timestamp) {
    if (!timestamp) return 'December 2025';
    try {
      const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
      return date.toLocaleString('en-US', { month: 'long', year: 'numeric' });
    } catch {
      return 'December 2025';
    }
  }
};

