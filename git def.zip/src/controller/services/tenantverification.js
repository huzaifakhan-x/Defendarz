exports.tenantverification =  async (req, res) => {
  try {
    const applicationId = req.params.applicationId;
    const applicationRef = db.collection('Applications').doc(applicationId);

    // Update the application status to verified
    await applicationRef.update({
      verified: true,
      verifiedAt: firebase.firestore.FieldValue.serverTimestamp(),
      status: 'verified' // Optional: for UI updates
    });

    res.send('Verification successful');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error updating verification status');
  }
};