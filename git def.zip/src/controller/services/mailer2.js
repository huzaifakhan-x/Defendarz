const { db } = require('../../../firebase.js')


const mailer2 = async (req, res) => {
console.log("i am hereeeeeeeeeeeeeeeeeee in mailer2");
console.log(req.body.email);
const name = req.body.name;
console.log(name);
const email = req.body.email;
const token = req.body.verificationToken;
console.log('Token',token);
  const usersRef =  db.collection('users');
   const queryRef = await usersRef.where('email', '==', email && 'type' == 'Owner'  ).get();
      if (!queryRef.empty)   {
        console.log('i am here');
          res.status(400).json({ 
  error: "Email already exists",
  redirect: "/sign" 
});
      }
else{
  const transpoter = nodemailer2.createTransport({ 
            host:'smtp.gmail.com',
             port:587,
             secure:false,
             requireTLS:true,
             auth:{
                 user:'ayaanmughal18@gmail.com',
                 pass:'yvscdczabngzksft'
             }
         });
         const mailOptions={
             from:'ayaanmughal18@gmail.com',
             to:email,
             subject:"For Reset Password",
             html: "<p> Hiii  "+name  +"  tenant Please click the Link <a href=youtube.com>?id=${inviteRef.id} to shake hand. </a> using this token  "+  token+" " 
         }
         transpoter.sendMail(mailOptions, function(error , info){
                if(error){
                 console.log(error);
                }
                 else{
                     console.log("Mail has been sent:-" , info.response)
                 }
         }) 
          res.status(200).json({ message: "Email sent Successfully" } );
     }
    }
module.exports =  mailer2 ;