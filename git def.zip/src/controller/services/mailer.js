const { db } = require('../../../firebase.js')
const nodemailer = require("nodemailer");

const mailer = async (req, res) => {
console.log("i am herre in this mailer");
console.log(req.body.email);
const name = req.body.name;
console.log(name);
const email = req.body.email;
const token = req.body.token;
console.log(token);
  const usersRef =  db.collection('Applications');
  console.log('Hereeeeeeeeeeee')
  
const queryRef = await usersRef.where('email', '==', email).get();
  if (!queryRef.empty)   {
    console.log('i am here');
    res.send({"success":"0", "err":"Email you Entered is Already Rejistered , Try with another Email"  });
  }
  else{
    console.log('Hereeeeeeeeeeee ELSE')
  const transpoter = nodemailer.createTransport({ 
            host:'smtp.gmail.com',
             port:587,
             secure:false,
             requireTLS:true,
             auth:{
                 user:'ayaanmughal18@gmail.com',
                 pass:'yvscdczabngzksft'
             }
         });
         const mailOptions={
             from:'ayaanmughal18@gmail.com',
             to:email,
             subject:"For Reset Password",
             html: "<p> Hiii  "+name  +"  Please copy the Link <a href=http://localhost:5000/api/auth/resestpassword > to reset your password  </a> using this token  "+  token+" " 
         }
         transpoter.sendMail(mailOptions, function(error , info){
                if(error){
                 console.log(error);
                }
                 else{
                     console.log("Mail has been sent:-" , info.response)
                 }
         }) 
             await db.collection('users').doc(email).set({
                                email: email,
                                username: name,                           
                                token: token,
                                // createdAt: firebase.firestore.FieldValue.serverTimestamp()
                            });
            console.log("ENDDD")
          res.status(200).json({ message: "Email sent Successfully" } );
     }
    }
module.exports =  mailer ;