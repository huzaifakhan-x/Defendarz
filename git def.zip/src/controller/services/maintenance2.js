exports.maintenance2 = (req, res) => {
    console.log('i am here now');
    const requestId = req.query.id;
    console.log('Request ID:', requestId);
    console.log('Request ID:', requestId);
    console.log('Request ID:', requestId);
    console.log('Request ID:', requestId);
    res.render('pages/maintenance-detail', { requestId: requestId });
};