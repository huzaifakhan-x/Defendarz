const { db } = require('../../../firebase.js')
exports.gettenants=  async (req, res) => {
  console.log('Hereeeeeeeeeeeeeeeeeeeeeeeeeee')
  try {
    const { email } = req.query;

    if (!email) {
      return res.status(400).json({
        error: 'Email is required in request body'
      });
    }
    // Query Firestore for tenants with matching ownerEmail
    const tenantsSnapshot = await db.collection('users')
      .where('ownerEmail', '==', email.toLowerCase())
      .get();
    const tenants = [];
    tenantsSnapshot.forEach(doc => {
      tenants.push({
        id: doc.id,
        ...doc.data()
      });
    });
    res.json({
      success: true,
      tenants: tenants,
      count: tenants.length
    });
  } catch (error) {
    console.error('Error fetching tenants:', error);
    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
};