// Add this to your existing API routes
exports.getrequestbyid = async (req, res) => {
    console.log('Fetching request with ID:');
    console.log('Fetching request with ID:');
    console.log('Fetching request with ID:');
    console.log('Fetching request with ID:');
    try {
        const requestId = req.params.id;
        console.log('Fetching request with ID:', requestId);
        console.log('Fetching request with ID:', requestId);
        console.log('Fetching request with ID:', requestId);
        // Your logic to fetch the specific request by ID
        // This could be from your database or Firebase
        const request = await getRequestFromDatabase(requestId);
        
        if (request) {
            res.json({ success: true, request: request });
        } else {
            res.status(404).json({ success: false, message: 'Request not found' });
        }
    } catch (error) {
        console.error('Error fetching request:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};