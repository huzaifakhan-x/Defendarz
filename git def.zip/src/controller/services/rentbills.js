const { db } = require('../../../firebase.js')


exports.rentbills = async (req, res) => {
  try {
    console.log("Fetching rent bills...");
    const { ownerId, search = '' } = req.query;
    
    // If using Firebase in backend
    const snapshot = await db.collection('Bills')
      .where('ownerEmail', '==', ownerId)
      .where('billType', '==', 'rent')
      .get();
    
    const rentBills = [];
    snapshot.forEach(doc => {
      const data = doc.data();
      rentBills.push({
        id: doc.id,
        tenantName: data.tenantName,
        billType: data.billType || 'rent',
        month: data.month || 'N/A',
        year: data.year || 'N/A',
        uploadedAt: data.uploadedAt ,
        verified: data.verified || false,
        fileUrl: data.fileUrls ? data.fileUrls[0] : '',
        amount: data.amount || 0,
        status: data.verified ? 'verified' : 'pending'
      });
    });
    
    // Apply search filter if provided
    const filteredBills = search 
      ? rentBills.filter(bill => 
          bill.tenantName.toLowerCase().includes(search.toLowerCase())
        )
      : rentBills;
    
    res.json({
      success: true,
      bills: filteredBills,
      count: filteredBills.length,
      total: rentBills.length
    });
    
  } catch (error) {
    console.error('Error fetching rent bills:', error);
    res.status(500).json({ success: false, error: 'Failed to load rent bills' });
  }
};