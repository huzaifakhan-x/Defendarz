exports.getutillities=(req, res)=> {

    res.render('pages/getutillities' ,{err:"norm"});
  }