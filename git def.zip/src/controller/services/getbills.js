exports.getbills=(req, res)=> {

    res.render('pages/getbills' );
  }