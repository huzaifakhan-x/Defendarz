const { db } = require('../../../firebase.js')


const servicesdata = async (req, res) => {
                  console.log(req.body)

                 if(req.body.moduleName==="SP"){
                   console.log("SP");
                      const uname = req.cookies.namecookie;
                          console.log(uname);
                         const body =req.body;
                         const phoneNumber = req.body.phoneNumber;
                         console.log(phoneNumber);
                    const usersRef =  db.collection('Applications');
                            const querySnapshot = await usersRef.where('username', '==', uname ).get();
                           if (querySnapshot.empty)  return  res.render('pages/signin', {err:"username"});                                
                           const col= querySnapshot.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
                              
                          console.log(col);
                          let SP = col[0].spAttemptNo;
                            SP =SP+1; 
                      const newSp= `${SP} SP`;
                        const now = new Date();
                        const spTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); 
                        console.log(now, spTime);
                        if (querySnapshot.empty) {
                            console.log('No matching documents found.');
                            return res.status(400).json({ error: 'No matching user' });
                          }
                        if (!querySnapshot.empty) {
                        try {
                            const data = {  applyDateSp: now, applyTimeSp: spTime ,
                              username : uname,
                              phoneNumber: phoneNumber || null,
                              body:body }
                            for (const doc of querySnapshot.docs) {
                              await doc.ref.update({  spAttemptNo: SP }); // <-- update your boolean field here
                              console.log(`Updated SP for user: ${doc.id}`);
                            }
                         
                              await db.collection('Applications').doc(newSp).set({
                                data,
                                spNo: SP 
                              });
                              

                            console.log(col);
                            return res.status(200).json({ message: 'NDC applied' , timeSp: spTime, col: col });
                          } catch (err) {
                            console.error('Error updating documents for NDC:', err);
                            return res.status(500).json({ error: 'Update failed' });
                          }
                        } else {
                            console.log('No matching documents found.');
                    }

                    };
                  if(req.body.moduleName==="NDC"){
                            console.log("NDC module detected");

                          console.log(req.body)
                          const username = req.cookies.namecookie;
                          const email = req.cookies.email;
                              console.log(username);
                          const body =req.body;
                          const usersRef =  db.collection('Applications');
                                  const querySnapshot = await usersRef.where('username', '==', username ).get();
                      
                                const col= querySnapshot.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
                              
                        console.log(col); 
                        console.log("col2 data for NDC attempt no:");    
                    
                        let NDC = col[0].ndcAttemptNo;
                        console.log("NDC value:", NDC);
                        NDC=NDC+1;
                        // NDC='NDC'
                        var ndcNo =  NDC;
                        console.log(ndcNo); // Concatenate 'NDC' with the incremented number
                     console.log("NDC incremented value:", NDC);
                     const newNdc= `${NDC} NDC`
                      const now = new Date();
                        const ndcTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); 
                          console.log(now, ndcTime);
                          if (querySnapshot.empty) {
                            console.log('No matching documents found.');
                            return res.status(400).json({ error: 'No matching user' });
                          }

                          // Use for..of  so we can await each update and then send a single response
                          try {
                            const data = {  dateNDC: now, applyTimeNDC: ndcTime , body:body ,
                              username : username,
                                // phoneNumber: phoneNumber || null,
                
                            }
                            for (const doc of querySnapshot.docs) {
                              await doc.ref.update({  ndcAttemptNo: NDC }); // <-- update your boolean field here
                              console.log(`Updated NDC for user: ${doc.id}`);
                            }
                         console.log("Herer&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
                              await db.collection('Applications').doc(newNdc).set({
                                data,
                                ndcNo: NDC,

                              });
                              
                            console.log(col);
                            return res.status(200).json({ message: 'NDC applied' , timeNdc: ndcTime, col: col });
                          } catch (err) {
                            console.error('Error updating documents for NDC:', err);
                            return res.status(500).json({ error: 'Update failed' });
                          }


                        }

                        if(req.body.moduleName==="OT"){
                          console.log("OT module detected");
                          const body =req.body
                                              const uname = req.cookies.namecookie;
                                                  console.log(uname);
                            console.log(req.body.phone)
                            const phoneNumber = req.body.phone;
                            const usersRef =  db.collection('Applications');
                            const querySnapshot = await usersRef.where('username', '==', uname ).get();
                            // if (queryRef.empty)  return res.status(400).send("Invalid Email or password");
                          
                            if (querySnapshot.empty)  return  res.render('pages/signin', {err:"username"});
                          
                                const col= querySnapshot.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
                        
                    let OT = col[0].otAttemptNo;
                        console.log("OT value:", OT);
                        OT=OT+1;
                        // NDC='NDC'
                        var otNo =  OT;
                        console.log(otNo); // Concatenate 'NDC' with the incremented number
                     console.log("OT incremented value:", OT);
                     const newOT= `${OT} OT`
                    const now = new Date();
                    const otTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); 
                    console.log(now, otTime);
                if (querySnapshot.empty) {
                            console.log('No matching documents found.');
                            return res.status(400).json({ error: 'No matching user' });
                          }
                    if (!querySnapshot.empty) {
                         try {
                            const data = {  dateOt: now, timeOt: otTime ,
                              username: uname,
                             phoneNumber: phoneNumber || null,
                               body:body }
                            for (const doc of querySnapshot.docs) {
                              await doc.ref.update({  otAttemptNo: OT }); // <-- update your boolean field here
                              console.log(`Updated OT for user: ${doc.id}`);
                            }
                         
                              await db.collection('Applications').doc(newOT).set({
                                data,
                                otNo: OT
                              });
                              
                            console.log(col);
                            return res.status(200).json({ message: 'OT applied' , applyTimeOT: otTime, col: col });
                          } catch (err) {
                            console.error('Error updating documents for OT:', err);
                            return res.status(500).json({ error: 'Update failed' });
                          }

                              } else {
                                  console.log('No matching documents found.');
                              }

                                }
                                //   // Handle OT module upload
                                if(req.body.moduleName==="LH"){
                                
                                console.log("LH module detected");
                          const body =req.body
                          const phoneNumber =req.body.phone
                          const uname = req.cookies.namecookie;
                          console.log(uname);

                            const usersRef =  db.collection('Applications');
                            const querySnapshot = await usersRef.where('username', '==', uname ).get();
                            // if (queryRef.empty)  return res.status(400).send("Invalid Email or password");
                          
                            if (querySnapshot.empty)  return  res.render('pages/signin', {err:"username"});
                          
                                const col= querySnapshot.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
                        
                                    console.log(col);
                       let LH = col[0].lhAttemptNo;
                        console.log("LH value:", LH);
                        LH=LH+1;
                          var lhNo =  LH;
                        console.log(lhNo); 
                         console.log("LH incremented value:", LH);
                     const newLH= `${LH} LH`
                                  const now = new Date();
                                  const lhTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); 
                                  console.log(now, lhTime);
                                     if (querySnapshot.empty) {
                            console.log('No matching documents found.');
                            return res.status(400).json({ error: 'No matching user' });
                          }

                                  if (!querySnapshot.empty) {
                                        try {
                            const data = {  dateLh: now, timeLh: lhTime ,
                                 username: uname,
                             phoneNumber: phoneNumber || null,
                              body:body }
                            for (const doc of querySnapshot.docs) {
                              await doc.ref.update({  lhAttemptNo: LH }); // <-- update your boolean field here
                              console.log(`Updated LH for user: ${doc.id}`);
                            }
                         
                              await db.collection('Applications').doc(newLH).set({
                                data,
                                lhNo: LH,

                              });
                              
                            console.log(col);
                            return res.status(200).json({ message: ' LH applied' , applyTimeLH: lhTime, col: col });
                          } catch (err) {
                            console.error('Error updating documents for LH:', err);
                            return res.status(500).json({ error: 'Update failed' });
                          }                 

                                  } else {
                                      console.log('No matching documents found.');
                                  }

                    };
                        if(req.body.moduleName==="POA"){
                        console.log("POAAAAA.........");

                    const body =req.body;
                    const phoneNumber =req.body.phone;
                      const uname = req.cookies.namecookie;
                          console.log(uname);
                    const usersRef =  db.collection('Applications');
                            const querySnapshot = await usersRef.where('username', '==', uname ).get();
                            // if (queryRef.empty)  return res.status(400).send("Invalid Email or password");
                          
                            if (querySnapshot.empty)  return  res.render('pages/signin', {err:"username"});
                          
                                const col= querySnapshot.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
                        
                     console.log(col);
                let POA = col[0].poaAttemptNo;
                                  console.log("POA value:", POA);
                        POA=POA+1;
                          var poaNo =  POA;
                        console.log(poaNo); 
                         console.log("POA incremented value:", POA);
                     const newPOA= `${POA} POA`
                                  const now = new Date();
                                  const poaTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); 
                                  console.log(now, poaTime);
                                      if (querySnapshot.empty) {
                            console.log('No matching documents found.');
                            return res.status(400).json({ error: 'No matching user' });
                          }
                                  if (!querySnapshot.empty) {
                                                          try {
                            const data = {  datePoa: now, timePoa: poaTime , 
                              
                                 username: uname,
                             phoneNumber: phoneNumber || null,
                              
                              body:body }
                            for (const doc of querySnapshot.docs) {
                              await doc.ref.update({  poaAttemptNo: POA }); // <-- update your boolean field here
                              console.log(`Updated POA for user: ${doc.id}`);
                            }
                         
                              await db.collection('Applications').doc(newPOA).set({
                                data,
                                poaNo: POA
                              });
                              
                            console.log(col);
                            return res.status(200).json({ message: ' POA applied' , applyTimePOA: poaTime, col: col });
                          } catch (err) {
                            console.error('Error updating documents for POA:', err);
                            return res.status(500).json({ error: 'Update failed' });
                          } 

                                  } else {
                                      console.log('No matching documents found.');
                                  }
}
                        if(req.body.moduleName==="CPOA"){
                        console.log("POAAAAA.........");

                      const uname = req.cookies.namecookie;
                          console.log(uname);

                    const usersRef =  db.collection('Applications');
                            const querySnapshot = await usersRef.where('username', '==', uname ).get();
                            // if (queryRef.empty)  return res.status(400).send("Invalid Email or password");
                          
                            
                            if (querySnapshot.empty)  return  res.render('pages/signin', {err:"username"});
                          
                                const col= querySnapshot.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
                        
                     console.log(col);
                let CPOA = col[0].cpoaAttemptNo;
                                  console.log("CPOA value:", POA);
                        CPOA=CPOA+1;
                          var cpoaNo =  CPOA;
                        console.log(cpoaNo); 
                         console.log("CPOA incremented value:", POA);
                     const newCPOA= `${CPOA} POA`
                                  const now = new Date();
                                  const cpoaTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); 
                                  console.log(now, cpoaTime);
                                      if (querySnapshot.empty) {
                            console.log('No matching documents found.');
                            return res.status(400).json({ error: 'No matching user' });
                          }
                                  if (!querySnapshot.empty) {
                                                          try {
                            const data = {  dateCpoa: now, timeCpoa: cpoaTime , 
                              
                                 username: uname,
                             phoneNumber: phoneNumber || null,
                              
                              body:body }
                            for (const doc of querySnapshot.docs) {
                              await doc.ref.update({  cpoaAttemptNo: CPOA }); // <-- update your boolean field here
                              console.log(`Updated POA for user: ${doc.id}`);
                            }
                         
                              await db.collection('Applications').doc(newCPOA).set({
                                data,
                                poaNo: CPOA
                              });
                              
                            console.log(col);
                            return res.status(200).json({ message: ' CPOA applied' , applyTimeCPOA: cpoaTime, col: col });
                          } catch (err) {
                            console.error('Error updating documents for CPOA:', err);
                            return res.status(500).json({ error: 'Update failed' });
                          } 

                                  } else {
                                      console.log('No matching documents found.');
                                  }
}
}

module.exports =  servicesdata ;

