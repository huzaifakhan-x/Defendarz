const { db } = require('../../../firebase.js')
// Endpoint: GET /api/dashboard/utility-bills
exports.utilitybills = async (req, res) => {
    
  try {
    console.log('Fetching utility bills with query:', req.query);
  
    const { ownerId, utilityType = 'electricity', search = '', month = '', year = '' } = req.query;
    
    const snapshot = await db.collection('Bills')
      .where('ownerEmail', '==', ownerId)
      .get();
    
    const utilityBills = [];
    snapshot.forEach(doc => {
      const data = doc.data();
      const billType = data.billType?.toLowerCase();
      
      // Skip rent bills
      if (billType === 'rent') return;
      
      // Filter by utility type if specified
      if (utilityType && billType !== utilityType.toLowerCase()) return;
      
      // Filter by month and year if specified
      const billMonth = (data.month || '').toString().toLowerCase();
      const billYear = (data.year || '').toString();
      
      if (month && billMonth !== month.toString().toLowerCase()) return;
      if (year && billYear !== year.toString()) return;
      
      utilityBills.push({
        id: doc.id,
        tenantName: data.tenantName,
        billType: billType,
        month: data.month || 'N/A',
        year: data.year || 'N/A',
        uploadedAt: data.uploadedAt || null,
        fileUrl: data.fileUrls ? data.fileUrls[0] : '',
        amount: data.amount || 0,
        consumption: data.consumption || 'N/A'
      });
    });
    // Apply search filter
    const filteredBills = search 
    ? utilityBills.filter(bill => 
      bill.tenantName.toLowerCase().includes(search.toLowerCase())
    )
    : utilityBills;
    console.log('FILTERED..............',filteredBills)
    console.log(filteredBills)

    
    res.json({
      success: true,
      data: filteredBills,
      count: filteredBills.length,
      byType: {
        electricity: utilityBills.filter(b => b.billType === 'electricity').length,
        gas: utilityBills.filter(b => b.billType === 'gas').length,
        water: utilityBills.filter(b => b.billType === 'water').length
      }
    });
    
  } catch (error) {
    console.error('Error fetching utility bills:', error);
    res.status(500).json({ success: false, error: 'Failed to load utility bills' });
  }};