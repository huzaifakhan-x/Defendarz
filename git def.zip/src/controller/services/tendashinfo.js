const { db } = require('../../../firebase.js')
// routes/tenant.js
exports.tendashinfo =  async (req, res) => {
    try {
        // Get parameters from query string
        const { tenantEmail, tenantName, dueDay } = req.query;
        
        if (!tenantEmail || !tenantName) {
            return res.status(400).json({ 
                success: false, 
                error: 'Missing required parameters: tenantEmail and tenantName' 
            });
        }
        
        console.log(`Fetching dashboard for: ${tenantEmail}, Name: ${tenantName}`);
        
        // Get tenant info from Firestore
        const tenantDoc = await db.collection("users").doc(tenantEmail).get();
        
        if (!tenantDoc.exists) {
            return res.status(404).json({ 
                success: false, 
                error: 'Tenant not found in database' 
            });
        }
        
        const tenantData = tenantDoc.data();
        
        // Get maintenance counts
        const maintenanceSnapshot = await db.collection("maintenanceRequests")
            .where("nameEmail", "==", tenantEmail)
            .get();
        
        const openRequests = maintenanceSnapshot.docs.filter(doc => 
            ['new', 'acknowledged', 'in_progress'].includes(doc.data().status)
        ).length;
        
        // Get announcements
        const announcementsSnapshot = await db.collection("announcements")
            .where('target', 'in', ['all', 'tenants'])
            .orderBy("createdAt", "desc")
            .limit(3)
            .get();
        
        const announcements = announcementsSnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        
        // Calculate dates
        const nextDueDate = calculateNextDueDate(dueDay || 1);
        const daysUntilDue = calculateDaysUntilDue(nextDueDate);
        
        // Utility estimates
        const electricity = Math.floor(Math.random() * 2000) + 1000;
        const water = Math.floor(Math.random() * 1000) + 500;
        const gas = Math.floor(Math.random() * 1500) + 800;
        const internet = Math.floor(Math.random() * 3000) + 2000;
        const totalUtilities = electricity + water + gas + internet;
        
        res.json({
            success: true,
            data: {
                tenantInfo: {
                    name: tenantData.name || tenantName,
                    email: tenantData.email || tenantEmail,
                    property: tenantData.property || 'N/A',
                    rent: tenantData.rent || 0,
                    dueDay: dueDay || 1,
                    unit: tenantData.unit || 'N/A',
                    registeredAt: tenantData.registeredAt
                },
                quickStats: {
                    openRequests,
                    totalUtilities,
                    electricity,
                    water,
                    gas,
                    internet
                },
                announcements: announcements,
                nextDueDate: nextDueDate,
                daysUntilDue: daysUntilDue
            }
        });
        
    } catch (error) {
        console.error('Error fetching dashboard info:', error);
        res.status(500).json({ 
            success: false, 
            error: 'Server error',
            message: error.message 
        });
    }
};