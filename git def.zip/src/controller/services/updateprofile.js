const { db } = require('../../../firebase.js')
// UPDATE Profile endpoint (Minimal)
exports.updateprofile = async (req, res) => {
  try {
    console.log('UPDATE PROFILE REQ BODY:', req.body);
    console.log('UPDATE PROFILE REQ BODY:', req.body);
    console.log('UPDATE PROFILE REQ BODY:', req.body);
    const { ownerId, firstName, email, phone, address } = req.body;
    
    if (!ownerId) {
      return res.status(400).json({ success: false, message: 'Owner ID required' });
    }
    
    const profileRef = db.collection('users').doc(ownerId);
    const profileDoc = await profileRef.get();
    
    if (!profileDoc.exists) {
      return res.status(404).json({ success: false, message: 'Profile not found' });
    }
    console.log('i am here #############################')
    const updateData = { updatedAt: new Date().toISOString() };
    
    if (firstName) updateData.firstName = firstName;
    if (email) updateData.email = email.toLowerCase();
    if (phone !== undefined) updateData.phone = phone;
    if (address !== undefined) updateData.address = address;
    
    await profileRef.update(updateData);
    
    res.json({ 
      success: true, 
      message: 'Profile updated' 
    });
    
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// Helper
