const { db } = require('../../../firebase.js')

exports.maintenance = async (req, res) => {
    console.log('i am here now');
    const requestId = req.query.id;
    console.log('Request ID:', requestId);
    
    try {
        // Reference to the maintenanceRequests collection
        const maintenanceRef = db.collection('maintenanceRequests');
        
        // Get the specific document by ID
        const doc = await maintenanceRef.doc(requestId).get();
        
        if (!doc.exists) {
            console.log('No such document!');
            return res.status(404).render('pages/error', { message: 'Request not found' });
        }
        
        // Get the document data
        const requestData = doc.data();
        
        console.log('Document data:', requestData);
        
        // Render the page with the fetched data
        res.render('pages/maintenance-detail', { 
            requestData: requestData,
            requestId: requestId 
        });
        
    } catch (error) {
        console.error('Error fetching document:', error);
        res.status(500).render('pages/error', { message: 'Error fetching request data' });
    }
};