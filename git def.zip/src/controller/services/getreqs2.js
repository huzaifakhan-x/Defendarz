exports.getreqs2 = (req, res) => {
    console.log('i am here now in New APIIII  %%%%%%%%%%%%%%%%');
    const requestId = req.params.id;
    console.log('Request ID:', requestId);
    console.log('Request ID:', requestId);
    console.log('Request ID:', requestId);
    console.log('Request ID:', requestId);
     res.json({
      success: true,
      requests: requests,
      count: requests.length
    });
    // res.render('pages/maintenance-detail', { requestId: requestId });
};