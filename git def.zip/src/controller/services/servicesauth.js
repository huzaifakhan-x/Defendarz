exports.servicesauth = (req, res) => {
    console.log("=== Tenant DASHBOARD ROUTE HIT ==="); 
    console.log("D22222222222222222");
    console.log("Request method:", req.method);
    console.log("Request body data:", req.body); 
  const token = req.body.token;
  console.log(token);

 if (!token || req.body.type !== "Owner") {
    console.log(!token ? "No token provided in request body" : "not a tenant");
     return res.send({"success":"0" });
}
else {

res.send({"success":"1" });



}
};