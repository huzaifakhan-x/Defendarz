exports.dashboard2 = (req, res) => {
    console.log("=== DASHBOARD ROUTE HIT ==="); 
    console.log("D22222222222222222");
    console.log("Request method:", req.method);
    console.log("Request body data:", req.body); 
  const token = req.body.token;
  console.log(token);

    if (!token) {
        console.log("No token provided in request body");
        return res.send({"success":"0"});
    }
     if (req.body.type != "Owner") {
        console.log('not a Owner');
       return res.send({"success":"0"});
    }
    const isAjax = req.xhr || (req.headers.accept && req.headers.accept.indexOf('json') > -1);
    console.log("Is AJAX request:", isAjax);
    
    if (isAjax) {
        console.log("i am here AJax .,.....");
        console.log("i am here ");
        console.log("✅ Processing AJAX request with data:", req.body);
        return res.json({"success": "1", "receivedData": req.body});
    } else {
        console.log("✅ Rendering page");
        res.render('/', { 
            loggedInOwnerId: req.user ? req.user.id : "", 
            name: req.user ? req.user.name : "" 
        });
    }
};