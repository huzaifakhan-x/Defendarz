const { db } = require('../../../firebase.js')

exports.postBills = async (req, res) => {
console.log(' i am in api .......POSTBILLS')
console.log(req.body);
const gasBill = req.body.gasBill;
const waterBill = req.body.waterBill;
console.log(gasBill);
console.log(waterBill);

const electricityBill = req.body.electricityBill;
console.log('elc',electricityBill);   
const rentPaid = req.body.rentPaid;
console.log('rent',rentPaid);
const username = req.cookies.namecookie;
console.log('user',username);
console.log(username);

console.log("i am here in utillities.....");

      const usersRef =  db.collection('users');
      const queryRef = await usersRef.where('username', '==', username  ).where('type', '==', 'tenant').get();
      const col = queryRef.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
      console.log(col);
      const ownerEmail  = col[0].ownerEmail;
      console.log(ownerEmail);
       const usersRef2 =  db.collection('users');
      
        const queryRef2 = await usersRef2.where('email', '==', ownerEmail  ).get();
        const col2= queryRef2.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
          console.log(col2);
          const ownerId  = col[0].id ;

         await db.collection('Utillities').doc(username).set({
                        ownerId,                
                        gasBill,
                        electricityBill,
                        rentPaid,
                        username,  
                        waterBill,
                        submittedAt: new Date(),                    
                            });
                            
      res.status(200).send('Bills uploaded successfully');
}