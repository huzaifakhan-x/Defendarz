exports.mtnc=(req, res)=> {

    res.render('pages/mtnc' );
  }