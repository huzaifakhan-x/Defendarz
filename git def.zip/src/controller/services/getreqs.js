const { db } = require('../../../firebase.js')
exports.getreqs=  async (req, res) => {
  console.log('HEREEEEEEEEEEEE');
  try {
    const { email } = req.query;

    if (!email) {
      return res.status(400).json({
        error: 'Email is required in request body'
      });
    }
    // Query Firestore for tenants with matching ownerEmail
    const requestsSnapshot = await db.collection('maintenanceRequests')
      .where('nameEmail', '==', email.toLowerCase())
      .get();
    const requests = [];
    requestsSnapshot.forEach(doc => {
      requests.push({
        id: doc.id,
        ...doc.data()
      });
    });
    res.json({
      success: true,
      requests: requests,
      count: requests.length
    });
  } catch (error) {
    console.error('Error fetching requests:', error);
    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }

};