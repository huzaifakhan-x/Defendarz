const { db } = require('../../../firebase.js')

exports.getapps = async (req, res) => {
   try {
    const { username } = req.body;
    console.log('Searching for username:', username);

    // Validate input
    if (!username) {
      return res.status(400).json({
        success: false,
        message: 'Username is required in request body'
      });
    }

    // Query Firestore for documents where data.username matches
    const applicationsRef = db.collection('Applications');
    const snapshot = await applicationsRef.where('data.username', '==', username).get();

    console.log('Snapshot size:', snapshot.size);

    if (snapshot.empty) {
      return res.status(404).json({
        success: false,
        message: `No applications found for username: ${username}`
      });
    }

    // Prepare formatted response data for frontend table
    const applications = [];
    snapshot.forEach(doc => {
      const docData = doc.data();
    //   console.log(docData);
      
      // Extract data from nested structure
      const fullName = docData.data?.username || 'N/A';
      const phone = docData.data.body.phone || 'N/A';
      const type = docData.data.body.moduleName || 'N/A';
      const address = docData.data?.body?.address || 'N/A';
      const applyTime = docData.data.body.applyTime|| 'N/A';
      const deadlineTime = docData.data.body.deadlineTime|| 'N/A';
      
      console.log(`📋 Extracted - Name: ${fullName}, Type: ${type}, Phone: ${phone}, ApplyTime : ${applyTime},
         DeadLine: ${deadlineTime} ` );

      // Format for frontend table
      applications.push({
        id: doc.id,
        fullName: fullName,
        phone: phone,
        type: type,
        address: address,
        applyTime: applyTime,
        // Include original data if needed
        rawData: docData
      });
    });
    console.log(applications)
    console.log('Total applications found:', applications.length);

    res.json({
      success: true,
      message: `Found ${applications.length} application(s) for username: ${username}`,
      data: applications,
      summary: {
        total: applications.length,
        pending: applications.length, // You can add status logic later
        approved: 0,
        expired: 0
      }
    });

  } catch (error) {
    console.error('Error fetching applications:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
};