const { db } = require('../../../firebase.js')

exports.postutillities = async (req, res) => {

console.log(req.body);
const gasBill = req.body.gasBill;
console.log(gasBill);

const electricityBill = req.body.electricityBill;
console.log('elc',electricityBill);   
const rentPaid = req.body.rentPaid;
console.log('rent',rentPaid);
const username = req.cookies.namecookie;
console.log('user',username);
console.log(username);

console.log("i am here in utillities.....");
console.log("i am here in utillities.....");

  const usersRef =  db.collection('Tenant');
      const queryRef = await usersRef.where('username', '==', username  ).get();
      const col = queryRef.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
      const ownerEmail  = col[0].ownerEmail;
console.log('owner email',ownerEmail);
console.log(col);
       const usersRef2 =  db.collection('users');
      
        const queryRef2 = await usersRef2.where('email', '==', ownerEmail  ).get();
      const col2= queryRef2.docs.map((doc)=> ({id:doc.id, ...doc.data()}))
console.log(col2);
const ownerName  = col[0].username;

         await db.collection('Utillities').doc(username).set({
                        ownerName,                
                        gasBill,
                        electricityBill,
                        rentPaid,
                        username, 
                        submittedAt: new Date(),                    
                            });
}
                  



