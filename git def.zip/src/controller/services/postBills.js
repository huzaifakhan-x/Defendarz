const { db } = require('../../../firebase.js');
const admin = require('firebase-admin');

exports.postBills = async (req, res) => {
    console.log('I am in api .......POSTBILLS');
    console.log(req.body);

    function formatDocName(tenantName, month, year ,billType ) {
        // Remove special characters and spaces, convert to lowercase
        const cleanName = tenantName.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        return `${cleanName}_${billType}_${month.toLowerCase()}_${year}`;
    }

    try {
        const { tenantName, month, year, billType, fileUrls , ownerEmail } = req.body;

        // Validate required fields
        if (!tenantName || !month || !year || !billType || !fileUrls || !ownerEmail) {
            return res.status(400).json({
                success: false,
                message: 'Missing required fields: tenantName, month, year, billType, fileUrls'
            });
        }

        // Validate bill type
        const validBillTypes = ['electricity', 'gas', 'water', 'rent'];
        if (!validBillTypes.includes(billType)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid bill type. Must be one of: electricity, gas, water, rent'
            });
        }

        // Format collection name
        const collectionName = 'Bills';
        const doc = formatDocName(tenantName, month, year , billType)
        console.log('Formatted document name:', doc);
        // Create bill data object
        const billData = {
            ownerEmail,
            tenantName,
            month,
            year,
            billType,
            fileUrls: Array.isArray(fileUrls) ? fileUrls : [fileUrls],
            uploadedAt: admin.firestore.FieldValue.serverTimestamp(),
            status: 'uploaded'
        };

        // Check if collection exists and get the document
        const collectionRef = db.collection(collectionName);
        const billDocRef = collectionRef.doc(doc);
        
        const existingDoc = await billDocRef.get();

        if (existingDoc.exists) {
            // COMPLETELY REPLACE THE EXISTING DOCUMENT
            await billDocRef.set(billData);
            console.log(`Replaced ${billType} bill for ${tenantName} - ${month} ${year}`);
        } else {
            // Create new document
            await billDocRef.set(billData);
            console.log(`Created new ${billType} bill for ${tenantName} - ${month} ${year}`);
        }

        // Get the updated document
        const updatedDoc = await billDocRef.get();

        // Send ONE response
        res.status(200).json({
            success: true,
            message: 'Bill uploaded successfully',
            data: {
                id: updatedDoc.id,
                ...updatedDoc.data()
            }
        });

    } catch (error) {
        console.error('Error uploading bill:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error.message
        });
    }
}