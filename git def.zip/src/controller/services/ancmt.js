exports.ancmt=(req, res)=> {

    res.render('pages/ancmt' );
  }