exports.dashboard = (req, res) => {
    console.log("=== DASHBOARD ROUTE HIT ===");
    console.log("Request method:", req.method);
    console.log("Request headers:", req.headers);
    console.log("Request query parameters:", req.query);
    console.log("Request body:", req.body);
    console.log("Is AJAX request?", req.xhr);
    console.log("Accept header:", req.headers.accept);
   
    // Check if it's an AJAX request
    const isAjax = req.xhr || (req.headers.accept && req.headers.accept.indexOf('json') > -1);
    console.log("Is AJAX request determined:", isAjax);
    
    if (isAjax) {
        console.log("✅ Returning JSON response for AJAX call");
        console.log("Auth data received:", req.body); // or req.query depending on how you send
        return res.json({"success": "1", "message": "AJAX call successful"});
    } else {
        console.log("✅ Rendering EJS page for direct browser request");
        // Get user data from authentication
        const loggedInOwnerId = req.user ? req.user.id : "default_id";
        const name = req.user ? req.user.name : "Guest User";
        
        console.log("Rendering with data - loggedInOwnerId:", loggedInOwnerId, "name:", name);
        
        res.render('pages/dashboard', { 
            loggedInOwnerId: loggedInOwnerId, 
            name: name ,
            keys : req.query
        });
    }
};