exports.gettenant=(req, res)=> {


    res.render('pages/gettenant' );
  }