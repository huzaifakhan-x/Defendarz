const functions = require("firebase-functions");
const dotenv = require("dotenv");
dotenv.config();

const express = require("express");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const cors = require("cors");

const app = express();
const allowedOrigin = "https://www.golfersestate.com";

app.use(cors({
  origin: allowedOrigin,
  credentials: true
}));

app.options(/.*/, cors({
  origin: allowedOrigin,
  credentials: true
}));

console.log("Herer");
// ✅ 1. Define environment flags FIRST (to avoid ReferenceError)
const isProduction = process.env.SERVER_TYPE === "PRODUCTION";
const FRONTEND_URL = isProduction ? process.env.LIVE_URL : process.env.LOCAL_URL;
console.log(FRONTEND_URL)

// ✅ 3. Middleware setup
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// ✅ 4. Static + EJS setup
app.set('view engine', 'ejs');
app.use(express.static(__dirname + "/public/"));

// Import routes and middleware
const routes = require('./src/routes');
const auth = require('./mw/auth');
const { signin3 } = require('./src/controller/auth/signin3');

// ✅ 5. Routes
app.get('/', async (req, res) => {
  res.render('pages/index.ejs');
});

app.get('/signup', async (req, res) => {
  res.render('pages/signup', { error: req.query.error });
});

app.get('/tenantsignup', async (req, res) => {
  res.render('pages/tenantsignup', { error: req.query.error });
});

app.get('/getutillities', async (req, res) => {
  res.render('pages/getutillities');
});

app.get("/debug-headers", (req, res) => {
  res.json({
    cookies: req.cookies,
    headers: req.headers,
  });
});
app.get("/all-properties", (req, res) => {
    res.render('pages/all-properties');
});
app.get("/addpropasowner", (req, res) => {
    res.render('pages/addpropasowner');
});
app.get("/addpropasagent", (req, res) => {
    res.render('pages/addpropasagent');
});

// ✅ Auth-protected routes
app.get('/ot',  async (req, res) => { res.render('pages/ot'); });
app.get('/otw',  async (req, res) => { res.render('pages/otw'); });
app.get('/ndc',  async (req, res) => { res.render('pages/ndc'); });
app.get('/ndcw',  async (req, res) => { res.render('pages/ndcw'); });
app.get('/sp',  async (req, res) => { res.render('pages/sp'); });
app.get('/poa',  async (req, res) => { res.render('pages/poa'); });
app.get('/poaw',  async (req, res) => { res.render('pages/poaw'); });
app.get('/cpoa',  async (req, res) => { res.render('pages/cpoa'); });
app.get('/cpoaw',  async (req, res) => { res.render('pages/cpoaw'); });
app.get('/lh',  async (req, res) => { res.render('pages/lh'); });
app.get('/ndclanding',  async (req, res) => { res.render('pages/ndc landing'); });
app.get('/lhlanding',  async (req, res) => { res.render('pages/lh landing'); });
app.get('/otlanding',  async (req, res) => { res.render('pages/ot landing'); });
app.get('/poalanding',  async (req, res) => { res.render('pages/poa landing'); });
app.get('/cpoalanding',  async (req, res) => { res.render('pages/cpoa landing'); });
app.get('/splanding',  async (req, res) => { res.render('pages/site plan landing'); });
app.get('/our-team',  async (req, res) => { res.render('pages/our-team'); });


// ✅ Chatbox routes
app.get('/chatbox', async (req, res) => {
  const name = req.cookies.namecookie;
  const email = req.cookies.emailcookie;
  const id = req.cookies.idcookie;
  const type = req.cookies.typecookie;

  function generateAvatar(name) {
    if (!name) return "U"; // default if missing
    const initials = name
      .split(' ')
      .map(word => word.charAt(0).toUpperCase())
      .join('');
    return initials;
  }

  const avatar = generateAvatar(name);
  res.render('pages/chatbox', { name, email, id, type, avatar });
});

app.get('/tenantchatbox', async (req, res) => {
  const name = req.cookies.nameCookie;
  const avatar = req.cookies.avatar;
  const email = req.cookies.tenantEmail;
  const ownerEmail = req.cookies.ownerEmail;
  const type = req.cookies.typecookie;
  console.log("Tenant name:", name);
  res.render('pages/tenantchatbox', { name, avatar, email, ownerEmail, type });
});

app.get('/tenantverification', async (req, res) => {
  console.log(req.query.token)
  res.render('pages/tenantverification' , { 
          token:req.query.token
        });
});

// ✅ API routes
app.post('/ndc', signin3);
app.use('/api', routes);

// ✅ 6. Localhost or Firebase mode
if (isProduction) {
  console.log("🚀 Running on Firebase (Production Mode)");
} else {
  app.listen(3000, () => {
    console.log("✅ Local server running on http://localhost:3000");
  });
}

// ✅ 7. Firebase export
exports.app = functions.https.onRequest(app);
